
# How to import demo authentication user in the firebase ?

1. Get files from the source zip

2. Get serviceAccountKey.json from firebase configuration 

3. npm install 

4. Run command node import-user.js

You can see the process of importing users in the firestore.

*Note: Do not close the terminal during the running process*
