import 'conversation_model.dart';

class ChatVideoContainer {
  Url videoUrl;

  String thumbnailUrl;

  ChatVideoContainer({required this.videoUrl, required this.thumbnailUrl});
}
